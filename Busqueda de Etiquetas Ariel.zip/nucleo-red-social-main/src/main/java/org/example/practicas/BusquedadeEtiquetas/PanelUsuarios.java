
package org.example.practicas.BusquedadeEtiquetas;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelUsuarios extends JFrame {

    // ===== PALETA OSCURA =====
    private static final Color FONDO = Color.decode("#121212");
    private static final Color TEXTO = Color.decode("#E0E0E0");
    private static final Color TEXTO_SEC = Color.decode("#A3A3A3");
    private static final Color TARJETA = Color.decode("#1E1E1E");
    private static final Color BOTON = Color.decode("#2A2A2A");
    private static final Color BOTON_HOVER = Color.decode("#363636");
    private static final Color BORDE = Color.decode("#333333");

    private ListaUsuarios lista;
    private ModeradorContenido moderador = new ModeradorContenido();

    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtEtiqueta;
    private JTextField txtBuscar;

    private JTable tabla;
    private DefaultTableModel modelo;

    public PanelUsuarios() {

        lista = new ListaUsuarios(100);

        cargarUsuarios();

        setTitle("SISTEMA DE GESTION DE USUARIOS");
        setSize(800, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(FONDO);

        JPanel principal = new JPanel(new BorderLayout(10, 10));
        principal.setBackground(FONDO);
        principal.setBorder(new EmptyBorder(10, 10, 10, 10));

        // ===== FORMULARIO =====
        JPanel formulario = new JPanel(new GridLayout(2, 4, 8, 8));
        estilizarTarjeta(formulario);

        txtCodigo = new JTextField();
        txtNombre = new JTextField();
        txtEtiqueta = new JTextField();

        estilizarCampo(txtCodigo);
        estilizarCampo(txtNombre);
        estilizarCampo(txtEtiqueta);

        JButton btnRegistrar = new JButton("Registrar");
        estilizarBoton(btnRegistrar);

        formulario.add(crearEtiqueta("Código:"));
        formulario.add(txtCodigo);

        formulario.add(crearEtiqueta("Nombre:"));
        formulario.add(txtNombre);

        formulario.add(crearEtiqueta("Etiqueta:"));
        formulario.add(txtEtiqueta);

        formulario.add(btnRegistrar);

        // ===== TABLA =====
        modelo = new DefaultTableModel(
                new String[]{"Código", "Nombre", "Etiqueta"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        estilizarTabla(tabla);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.getViewport().setBackground(TARJETA);
        scroll.setBackground(TARJETA);
        scroll.setBorder(new LineBorder(BORDE));

        // ===== ORDENAMIENTO =====
        JPanel ordenamiento = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 8, 8)
        );
        estilizarTarjeta(ordenamiento);

        JButton btnOrdenarCodigo = new JButton("Ordenar por código");
        JButton btnOrdenarNombre = new JButton("Ordenar por nombre");

        estilizarBoton(btnOrdenarCodigo);
        estilizarBoton(btnOrdenarNombre);

        ordenamiento.add(btnOrdenarCodigo);
        ordenamiento.add(btnOrdenarNombre);

        // ===== BUSQUEDA =====
        JPanel busqueda = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 8, 8)
        );
        estilizarTarjeta(busqueda);

        txtBuscar = new JTextField(15);
        estilizarCampo(txtBuscar);

        JButton btnBuscarCodigo = new JButton("Buscar ID");
        JButton btnBuscarNombre = new JButton("Buscar nombre");
        JButton btnBuscarEtiqueta = new JButton("Buscar etiqueta");

        estilizarBoton(btnBuscarCodigo);
        estilizarBoton(btnBuscarNombre);
        estilizarBoton(btnBuscarEtiqueta);

        busqueda.add(crearEtiqueta("Buscar:"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscarCodigo);
        busqueda.add(btnBuscarNombre);
        busqueda.add(btnBuscarEtiqueta);

        // ===== EVENTOS =====

        btnRegistrar.addActionListener(e -> registrar());

        btnOrdenarCodigo.addActionListener(e -> {
            lista.ordenarPorCodigo();
            actualizarTabla();
        });

        btnOrdenarNombre.addActionListener(e -> {
            lista.ordenarPorNombre();
            actualizarTabla();
        });

        btnBuscarCodigo.addActionListener(e -> buscarCodigo());

        btnBuscarNombre.addActionListener(e -> buscarNombre());

        btnBuscarEtiqueta.addActionListener(e -> buscarEtiqueta());

        // ===== PANEL INFERIOR =====
        JPanel inferior = new JPanel(new GridLayout(2, 1, 0, 10));
        inferior.setBackground(FONDO);

        inferior.add(ordenamiento);
        inferior.add(busqueda);

        // ===== DISTRIBUCION =====
        principal.add(formulario, BorderLayout.NORTH);
        principal.add(scroll, BorderLayout.CENTER);
        principal.add(inferior, BorderLayout.SOUTH);

        add(principal);

        actualizarTabla();
    }

    // ===== ESTILOS =====

    private void estilizarTarjeta(JPanel panel) {

        panel.setBackground(TARJETA);

        panel.setBorder(new CompoundBorder(
                new LineBorder(BORDE),
                new EmptyBorder(8, 8, 8, 8)
        ));
    }

    private JLabel crearEtiqueta(String texto) {

        JLabel label = new JLabel(texto);
        label.setForeground(TEXTO_SEC);

        return label;
    }

    private void estilizarCampo(JTextField campo) {

        campo.setBackground(FONDO);
        campo.setForeground(TEXTO);
        campo.setCaretColor(TEXTO);

        campo.setBorder(new CompoundBorder(
                new LineBorder(BORDE),
                new EmptyBorder(4, 6, 4, 6)
        ));
    }

    private void estilizarBoton(JButton boton) {

        boton.setBackground(BOTON);
        boton.setForeground(TEXTO);
        boton.setOpaque(true);
        boton.setContentAreaFilled(true);
        boton.setFocusPainted(false);

        boton.setBorder(new CompoundBorder(
                new LineBorder(BORDE),
                new EmptyBorder(6, 12, 6, 12)
        ));

        boton.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        boton.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(BOTON_HOVER);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                boton.setBackground(BOTON);
            }
        });
    }

    private void estilizarTabla(JTable t) {

        t.setBackground(TARJETA);
        t.setForeground(TEXTO);
        t.setGridColor(BORDE);

        t.setSelectionBackground(BOTON_HOVER);
        t.setSelectionForeground(TEXTO);

        t.setRowHeight(24);
        t.setFillsViewportHeight(true);

        JTableHeader header = t.getTableHeader();

        header.setReorderingAllowed(false);

        header.setDefaultRenderer(new DefaultTableCellRenderer() {

            @Override
            public Component getTableCellRendererComponent(
                    JTable table,
                    Object value,
                    boolean isSelected,
                    boolean hasFocus,
                    int row,
                    int column) {

                super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column
                );

                setBackground(BOTON);
                setForeground(TEXTO);
                setFont(getFont().deriveFont(Font.BOLD));

                setBorder(new CompoundBorder(
                        new MatteBorder(0, 0, 1, 1, BORDE),
                        new EmptyBorder(4, 6, 4, 6)
                ));

                return this;
            }
        });
    }

    // ===== DATOS DE PRUEBA =====

    private void cargarUsuarios() {

        lista.registrar(101, "Carlos", "estudiante");
        lista.registrar(102, "Andrea", "docente");
        lista.registrar(103, "Miguel", "estudiante");
        lista.registrar(104, "Patricia", "admin");
        lista.registrar(105, "Luis", "docente");
        lista.registrar(106, "Daniel", "estudiante");
        lista.registrar(107, "Pablo", "admin");
    }

    // ===== REGISTRAR =====

    private void registrar() {

        try {

            int codigo = Integer.parseInt(
                    txtCodigo.getText().trim()
            );

            String nombre = txtNombre.getText().trim();
            String etiqueta = txtEtiqueta.getText().trim();

            if (nombre.isEmpty() || etiqueta.isEmpty()) {

                JOptionPane.showMessageDialog(this,
                        "Complete todos los campos");

                return;
            }

            // MODERACION AUTOMATICA
            String infraccion = moderador.buscarInfraccion(nombre);

            if (infraccion == null) {
                infraccion = moderador.buscarInfraccion(etiqueta);
            }

            if (infraccion != null) {

                JOptionPane.showMessageDialog(this,
                        "Registro rechazado por moderación automática.\n"
                        + "Contenido no permitido: \"" + infraccion + "\"");

                return;
            }

            if (lista.registrar(codigo, nombre, etiqueta)) {

                JOptionPane.showMessageDialog(this,
                        "Usuario registrado correctamente");

                txtCodigo.setText("");
                txtNombre.setText("");
                txtEtiqueta.setText("");

                actualizarTabla();

            } else {

                JOptionPane.showMessageDialog(this,
                        "Código duplicado, lista llena o datos inválidos");
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Ingrese un código numérico válido");
        }
    }

    // ===== ACTUALIZAR TABLA =====

    private void actualizarTabla() {

        modelo.setRowCount(0);

        for (int i = 0; i < lista.getCantidad(); i++) {

            Usuario usuario = lista.obtener(i);

            if (usuario != null) {

                modelo.addRow(new Object[]{
                    usuario.getCodigo(),
                    usuario.getNombre(),
                    usuario.getEtiqueta()
                });
            }
        }
    }

    // ===== BUSCAR POR ID =====

    private void buscarCodigo() {

        try {

            int codigo = Integer.parseInt(
                    txtBuscar.getText().trim()
            );

            Usuario usuario = lista.buscarPorCodigo(codigo);

            if (usuario != null) {

                mostrarUsuario(usuario);

            } else {

                JOptionPane.showMessageDialog(this,
                        "Usuario no encontrado");
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Ingrese un código válido");
        }
    }

    // ===== BUSCAR POR NOMBRE =====

    private void buscarNombre() {

        String nombre = txtBuscar.getText().trim();

        if (nombre.isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Ingrese un nombre");

            return;
        }

        Usuario usuario = lista.buscarPorNombre(nombre);

        if (usuario != null) {

            mostrarUsuario(usuario);

        } else {

            JOptionPane.showMessageDialog(this,
                    "Usuario no encontrado");
        }
    }

    // ===== BUSCAR POR ETIQUETA =====

    private void buscarEtiqueta() {

        String etiqueta = txtBuscar.getText().trim();

        if (etiqueta.isEmpty()) {

            actualizarTabla();
            return;
        }

        Usuario[] encontrados = lista.buscarPorEtiqueta(etiqueta);

        if (encontrados == null || encontrados.length == 0) {

            JOptionPane.showMessageDialog(this,
                    "No hay usuarios con la etiqueta: " + etiqueta);

            return;
        }

        modelo.setRowCount(0);

        for (Usuario u : encontrados) {

            if (u != null) {

                modelo.addRow(new Object[]{
                    u.getCodigo(),
                    u.getNombre(),
                    u.getEtiqueta()
                });
            }
        }

        JOptionPane.showMessageDialog(this,
                encontrados.length + " usuario(s) con la etiqueta: "
                + etiqueta);
    }

    // ===== MOSTRAR USUARIO =====

    private void mostrarUsuario(Usuario usuario) {

        JOptionPane.showMessageDialog(this,
                "USUARIO ENCONTRADO\n\n"
                + "Código: " + usuario.getCodigo()
                + "\nNombre: " + usuario.getNombre()
                + "\nEtiqueta: " + usuario.getEtiqueta());
    }

    // ===== TEMA OSCURO =====

    private static void configurarTema() {

        try {

            UIManager.setLookAndFeel(
                    UIManager.getCrossPlatformLookAndFeelClassName()
            );

        } catch (Exception ignorada) {
        }

        UIManager.put("OptionPane.background", TARJETA);
        UIManager.put("Panel.background", TARJETA);
        UIManager.put("OptionPane.messageForeground", TEXTO);
        UIManager.put("Button.background", BOTON);
        UIManager.put("Button.foreground", TEXTO);
    }

    // ===== MAIN =====

    public static void main(String[] args) {

        configurarTema();

        SwingUtilities.invokeLater(() -> {
            new PanelUsuarios().setVisible(true);
        });
    }
}
