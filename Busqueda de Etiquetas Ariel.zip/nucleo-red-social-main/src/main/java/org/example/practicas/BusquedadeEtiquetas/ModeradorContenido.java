/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example.practicas.BusquedadeEtiquetas;

import java.text.Normalizer;
import java.util.Locale;
/**
 *
 * @author ARIEL
 */
public class ModeradorContenido {

    private final String[] palabrasProhibidas = {
        "idiota",
        "estupido",
        "imbecil",
        "inutil",
        "tonto",
        "maldito",
        "mierda",
        "basura",
        "odio",
        "amenaza",
        "matar",
        "golpear",
        "insulto",
        "estupida",
        "idiotas",
        "pendejo"
    };

    // Normalizar texto
    private String normalizar(String texto) {

        texto = texto.toLowerCase(Locale.ROOT);

        texto = Normalizer.normalize(
                texto, Normalizer.Form.NFD
        );

        return texto.replaceAll("\\p{M}", "");
    }

    // Buscar infracciones
    public String buscarInfraccion(String texto) {

        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }

        String contenido = normalizar(texto);

        for (String palabra : palabrasProhibidas) {

            String patron = "(?<![\\p{L}\\p{N}])"
                    + palabra
                    + "(?![\\p{L}\\p{N}])";

            if (contenido.matches("(?s).*" + patron + ".*")) {
                return palabra;
            }
        }

        return null;
    }

    // Comprobar contenido
    public boolean esContenidoPermitido(String texto) {

        return buscarInfraccion(texto) == null;
    }

    // Mostrar resultado
    public String moderar(String texto) {

        String infraccion = buscarInfraccion(texto);

        if (infraccion != null) {

            return "CONTENIDO RECHAZADO\n"
                    + "Palabra detectada: " + infraccion;
        }

        return "CONTENIDO APROBADO\n"
                + "No se encontraron infracciones.";
    }
}