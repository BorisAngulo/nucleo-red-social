
package org.example.practicas.Registro;

public class ListaUsuarios {

    private Usuario[] usuarios;
    private int cantidad;

    // CONSTRUCTOR
    public ListaUsuarios(int capacidad) {

        if (capacidad <= 0) {
            throw new IllegalArgumentException(
                    "La capacidad debe ser mayor que cero"
            );
        }

        usuarios = new Usuario[capacidad];
        cantidad = 0;
    }

    // REGISTRAR USUARIO
    public boolean registrar(int codigo, String nombre, String etiqueta) {

        if (nombre == null || nombre.trim().isEmpty()
                || etiqueta == null || etiqueta.trim().isEmpty()) {
            return false;
        }

        if (cantidad >= usuarios.length) {
            return false;
        }

        // Verificar código duplicado
        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getCodigo() == codigo) {
                return false;
            }
        }

        usuarios[cantidad] = new Usuario(
                codigo,
                nombre.trim(),
                etiqueta.trim()
        );

        cantidad++;

        return true;
    }

    // BUSQUEDA LINEAL POR ETIQUETA
    public Usuario[] buscarPorEtiqueta(String etiqueta) {

        if (etiqueta == null || etiqueta.trim().isEmpty()) {
            return new Usuario[0];
        }

        String buscada = etiqueta.trim();

        // Contar coincidencias
        int total = 0;

        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getEtiqueta().equalsIgnoreCase(buscada)) {
                total++;
            }
        }

        // Crear arreglo con el tamaño exacto
        Usuario[] resultado = new Usuario[total];

        int k = 0;

        for (int i = 0; i < cantidad; i++) {
            if (usuarios[i].getEtiqueta().equalsIgnoreCase(buscada)) {
                resultado[k] = usuarios[i];
                k++;
            }
        }

        return resultado;
    }

    // ORDENAR POR NOMBRE - METODO BURBUJA
    public void ordenarPorNombre() {

        for (int i = 0; i < cantidad - 1; i++) {

            for (int j = 0; j < cantidad - i - 1; j++) {

                if (usuarios[j].getNombre().compareToIgnoreCase(
                        usuarios[j + 1].getNombre()) > 0) {

                    Usuario aux = usuarios[j];
                    usuarios[j] = usuarios[j + 1];
                    usuarios[j + 1] = aux;
                }
            }
        }
    }

    // ORDENAR POR CODIGO - METODO BURBUJA
    public void ordenarPorCodigo() {

        for (int i = 0; i < cantidad - 1; i++) {

            for (int j = 0; j < cantidad - i - 1; j++) {

                if (usuarios[j].getCodigo() > usuarios[j + 1].getCodigo()) {

                    Usuario aux = usuarios[j];
                    usuarios[j] = usuarios[j + 1];
                    usuarios[j + 1] = aux;
                }
            }
        }
    }

    // BUSQUEDA BINARIA POR CODIGO
    public Usuario buscarPorCodigo(int codigo) {

        ordenarPorCodigo();

        int izquierda = 0;
        int derecha = cantidad - 1;

        while (izquierda <= derecha) {

            int medio = izquierda + (derecha - izquierda) / 2;

            int codigoActual = usuarios[medio].getCodigo();

            if (codigoActual == codigo) {
                return usuarios[medio];
            }

            if (codigoActual < codigo) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }

        return null;
    }

    // BUSQUEDA BINARIA POR NOMBRE
    public Usuario buscarPorNombre(String nombre) {

        if (nombre == null || nombre.trim().isEmpty()) {
            return null;
        }

        ordenarPorNombre();

        String buscado = nombre.trim();

        int izquierda = 0;
        int derecha = cantidad - 1;

        while (izquierda <= derecha) {

            int medio = izquierda + (derecha - izquierda) / 2;

            int comparacion = usuarios[medio].getNombre()
                    .compareToIgnoreCase(buscado);

            if (comparacion == 0) {
                return usuarios[medio];
            }

            if (comparacion < 0) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }

        return null;
    }

    // OBTENER USUARIO POR POSICION
    public Usuario obtener(int posicion) {

        if (posicion < 0 || posicion >= cantidad) {
            return null;
        }

        return usuarios[posicion];
    }

    // OBTENER CANTIDAD DE USUARIOS
    public int getCantidad() {
        return cantidad;
    }

    // OBTENER CAPACIDAD MAXIMA
    public int getCapacidad() {
        return usuarios.length;
    }

    // VERIFICAR SI LA LISTA ESTA VACIA
    public boolean estaVacia() {
        return cantidad == 0;
    }

    // VERIFICAR SI LA LISTA ESTA LLENA
    public boolean estaLlena() {
        return cantidad == usuarios.length;
    }
}
