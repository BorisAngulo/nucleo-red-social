/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package org.example.practicas.Registro;
import java.util.Scanner;

/**
 *
 * @author ARIEL
 */
public class Main {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ModeradorContenido moderador = new ModeradorContenido();

        System.out.println("===== MODERADOR DE CONTENIDO =====");
        System.out.print("Escribe un comentario: ");

        String texto = sc.nextLine();

        String resultado = moderador.moderar(texto);

        System.out.println("\n" + resultado);

        sc.close();
    }
}