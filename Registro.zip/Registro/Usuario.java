
package org.example.practicas.Registro;

public class Usuario {

    private int codigo;
    private String nombre;
    private String etiqueta;

    // Constructor de tres parámetros
    public Usuario(int codigo, String nombre, String etiqueta) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.etiqueta = etiqueta;
    }

    // Constructor de dos parámetros para mantener compatibilidad
    public Usuario(int codigo, String nombre) {
        this(codigo, nombre, "");
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEtiqueta(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " - " + etiqueta;
    }
}
